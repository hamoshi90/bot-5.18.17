# -*- coding: utf-8 -*-
"""[R6-PLUS12] وحدة ربط لوحة الوكيل (55bets / Affigates API).

تعمل مباشرة مع الـAPI الخلفي للوحة (خلف واجهة React):
    POST /global/api/User/signIn               {username, password}
    GET  /global/api/User/get-current-user-info
    POST /global/api/Player/getPlayersForCurrentAgent
    POST /global/api/Player/getPlayerBalanceById  {playerId}
    POST /global/api/Player/registerPlayer
    POST /global/api/Player/depositToPlayer       {amount, comment, playerId, currencyCode}
    POST /global/api/Player/withdrawFromPlayer    (النموذج نفسه)
"""

import os
import re
import asyncio
import logging
import secrets
from datetime import datetime, timezone
from typing import Optional

try:
    import aiohttp
except ImportError:  # pragma: no cover
    aiohttp = None

try:  # [PROXY-OUT] دعم socks5:// (اختياري)
    import aiohttp_socks
except ImportError:  # pragma: no cover
    aiohttp_socks = None

logger = logging.getLogger("bot.panel")

DEFAULT_PANEL_URL = "https://agents.55bets.net"


class PanelError(Exception):
    """فشل عملية على اللوحة — رسالة جاهزة للعرض."""


class PanelNotConfigured(PanelError):
    """بيانات اللوحة غير مضبوطة في البيئة."""


class PanelAuthError(PanelError):
    """الخادم رفض الوصول (401/403) — يستدعي إعادة دخول تلقائية."""


def panel_config() -> dict:
    """قراءة إعدادات اللوحة من البيئة."""
    return {
        "base": (os.getenv("BETS55_PANEL_URL") or DEFAULT_PANEL_URL).strip().rstrip("/"),
        "user": (os.getenv("BETS55_AGENT_USER") or "").strip(),
        "pass": (os.getenv("BETS55_AGENT_PASS") or "").strip(),
        "currency": (os.getenv("BETS55_CURRENCY") or "NSP").strip(),
        "country": (os.getenv("BETS55_COUNTRY") or "SY").strip(),
    }


def panel_configured() -> bool:
    c = panel_config()
    return bool(c["user"] and c["pass"])


def parse_wallet(raw) -> float:
    """تحويل «NSP 20892.50» أو الأرقام المباشرة إلى float."""
    if raw is None:
        return 0.0
    if isinstance(raw, (int, float)):
        return float(raw)
    m = re.search(r"(-?\d[\d,]*(?:\.\d+)?)", str(raw))
    if not m:
        return 0.0
    try:
        return float(m.group(1).replace(",", ""))
    except ValueError:
        return 0.0


# [R6-PLUS13] حالة آخر تواصل مع اللوحة — تظهر في /ops
PANEL_STATE = {
    "last_ok": "",
    "last_error": "",
    "last_error_at": "",
    "wallet": None,
    "available": None,
    "currency": "",
    "players": None,
}


def panel_state() -> dict:
    return dict(PANEL_STATE)


def _state_note_ok(**kw):
    PANEL_STATE["last_ok"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    PANEL_STATE["last_error"] = ""
    PANEL_STATE["last_error_at"] = ""
    for k, v in kw.items():
        if v is not None:
            PANEL_STATE[k] = v


def _state_note_err(err: str):
    PANEL_STATE["last_error"] = str(err)[:120]
    PANEL_STATE["last_error_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")


class PanelClient:
    """عميل لوحة الوكيل — جلسة موحدة مع إعادة مصادقة تلقائية وحماية من تعارض الحلقات."""

    def __init__(self, config: dict = None):
        self.cfg = config or panel_config()
        self._sess: Optional["aiohttp.ClientSession"] = None
        self._logged = False
        self._lock: Optional[asyncio.Lock] = None

    def _get_lock(self) -> asyncio.Lock:
        """تهيئة القفل بكسل لتفادي ربطه بحلقة أحداث غير مفعلة."""
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def close(self):
        if self._sess and not self._sess.closed:
            await self._sess.close()
        self._sess = None
        self._logged = False

    def _api(self, path: str) -> str:
        return f"{self.cfg['base']}/global/api/{path}"

    @staticmethod
    def _headers() -> dict:
        return {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "Accept-Language": "en-GB,en;q=0.9",
        }

    @staticmethod
    def _proxy_url() -> Optional[str]:
        p = (os.getenv("BETS55_PROXY") or os.getenv("OUTBOUND_PROXY") or "").strip()
        return p or None

    def _new_session(self) -> "aiohttp.ClientSession":
        timeout = aiohttp.ClientTimeout(total=30)
        proxy = self._proxy_url()
        connector = None

        if proxy and proxy.lower().startswith("socks"):
            if aiohttp_socks is None:
                raise PanelError("لدعم SOCKS5 ثبّت: pip install aiohttp-socks")
            connector = aiohttp_socks.ProxyConnector.from_url(proxy)

        return aiohttp.ClientSession(
            timeout=timeout,
            cookie_jar=aiohttp.CookieJar(unsafe=True),
            connector=connector,
        )

    def _origin_headers(self) -> dict:
        h = self._headers()
        h["Origin"] = self.cfg["base"]
        h["Referer"] = f"{self.cfg['base']}/"
        h["User-Agent"] = (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        )
        return h

    async def _request(self, method: str, path: str, json_body=None):
        if aiohttp is None:
            raise PanelError("مكتبة aiohttp غير متوفرة")

        if self._sess is None or self._sess.closed:
            self._sess = self._new_session()

        url = self._api(path)
        headers = self._origin_headers()
        proxy = self._proxy_url()

        if proxy and proxy.lower().startswith("socks"):
            proxy = None

        try:
            async with self._sess.request(
                method, url, json=json_body, headers=headers, proxy=proxy
            ) as resp:
                text = await resp.text()

                if resp.status in (401, 403):
                    head = text[:200].lstrip().lower()
                    if head.startswith(("<!doctype", "<html")):
                        raise PanelAuthError(
                            "اللوحة تحجب الوصول (جدار حماية/Cloudflare) — راجع الاتصال والبروكسي"
                        )
                    raise PanelAuthError(f"اللوحة رفضت الوصول (HTTP {resp.status})")

                if resp.status >= 500:
                    raise PanelError(f"خطأ من الخادم الداخلي للوحة ({resp.status})")

                try:
                    data = await resp.json(content_type=None)
                except Exception:
                    raise PanelError(f"رد غير متوقع من اللوحة ({resp.status}): {text[:60]}")

                return resp.status, data
        except asyncio.TimeoutError:
            raise PanelError("انتهت مهلة الاتصال باللوحة")
        except aiohttp.ClientError as exc:
            raise PanelError(f"تعذر الاتصال باللوحة: {type(exc).__name__}")

    @staticmethod
    def _unwrap(data) -> object:
        """استخراج result وتفادي الخلط بين النصوص العادية وأخطاء الجلسة."""
        if not isinstance(data, dict):
            raise PanelError("رد غير مفهوم من اللوحة")

        if data.get("status") is not True:
            msg = ""
            res = data.get("result")
            if isinstance(res, dict):
                msg = str(res.get("message") or "")
            if not msg:
                notif = data.get("notification")
                if isinstance(notif, list) and notif and isinstance(notif[0], dict):
                    msg = str(notif[0].get("content") or notif[0].get("message") or "")
            raise PanelError(msg or "رفضت اللوحة الطلب")

        res = data.get("result")

        # التحقق من أن النص ليس صفحة تسجيل دخول أو خطأ صلاحيات قبل رفع PanelAuthError
        if isinstance(res, str):
            res_lower = res.strip().lower()
            if res_lower.startswith(("<html", "<!doctype")) or any(
                term in res_lower for term in ("unauthorized", "unauthenticated", "session expired")
            ):
                raise PanelAuthError(f"انتهت الجلسة أو ردت اللوحة بصفحة دخول ({res[:40]})")

        return res

    async def _authed(self, method: str, path: str, json_body=None):
        lock = self._get_lock()
        async with lock:
            if not self._logged:
                await self.login()

            for attempt in (1, 2):
                try:
                    _, data = await self._request(method, path, json_body)
                    result = self._unwrap(data)
                    _state_note_ok()
                    return result
                except PanelAuthError:
                    if attempt == 2:
                        _state_note_err("انتهت جلسة اللوحة وتعذرت استعادتها")
                        raise
                    self._logged = False
                    await self.login()
                except PanelError as exc:
                    _state_note_err(str(exc))
                    raise

        raise PanelError("تعذر التواصل مع اللوحة")

    async def login(self):
        if not panel_configured():
            raise PanelNotConfigured("بيانات لوحة الوكيل غير مضبوطة (BETS55_AGENT_USER/PASS)")

        try:
            status, data = await self._request(
                "POST",
                "User/signIn",
                {"username": self.cfg["user"], "password": self.cfg["pass"]},
            )
        except PanelError as exc:
            self._logged = False
            _state_note_err(str(exc))
            raise

        if status != 200:
            self._logged = False
            _state_note_err(f"HTTP {status} عند الدخول")
            raise PanelError("فشل تسجيل الدخول للوحة")

        res = data.get("result") if isinstance(data, dict) else None

        # فحص بـ is not False لتفادي التداخل المنطقي بين 0 و False في بايثون
        if data.get("status") is True and res is not False and res is not None:
            self._logged = True
            logger.info("[panel] تم الدخول للوحة الوكيل بنجاح")
            return True

        msg = ""
        if isinstance(res, dict):
            msg = str(res.get("message") or "")
        if not msg:
            notif = data.get("notification") if isinstance(data, dict) else None
            if isinstance(notif, list) and notif and isinstance(notif[0], dict):
                msg = str(notif[0].get("content") or notif[0].get("message") or "")

        self._logged = False
        err = f"بيانات الدخول غير صحيحة ({msg})" if msg else "بيانات الدخول للوحة غير صحيحة"
        _state_note_err(err)
        raise PanelError(err)

    # ---------------- العمليات ----------------

    async def agent_info(self) -> dict:
        res = await self._authed("GET", "User/get-current-user-info")
        if not isinstance(res, dict):
            raise PanelError("رد معلومات الوكيل غير مفهوم")

        wallet = res.get("currentWallet") or ""
        available = res.get("availableWallet") or wallet
        info = {
            "username": res.get("username"),
            "affiliate_id": res.get("affiliateId"),
            "currency": res.get("mainCurrency") or self.cfg["currency"],
            "wallet": parse_wallet(wallet),
            "available": parse_wallet(available),
            "raw_available": str(available),
        }
        _state_note_ok(
            wallet=info["wallet"],
            available=info["available"],
            currency=info["currency"],
        )
        return info

    async def players(self) -> list:
        res = await self._authed("POST", "Player/getPlayersForCurrentAgent", {})
        if isinstance(res, dict):
            rows = list(res.get("records") or res.get("players") or res.get("data") or [])
        elif isinstance(res, list):
            rows = res
        else:
            rows = []

        if rows:
            _state_note_ok(players=len(rows))
        return rows

    async def all_wallets(self) -> list:
        """[AGENT-FULL] استخراج آمن لسجلات المحافظ دون تحويلها لمفاتيح نصية."""
        res = await self._authed("POST", "Agent/getAgentAllWallets", {})
        if isinstance(res, dict):
            return list(res.get("records") or res.get("wallets") or res.get("data") or [])
        if isinstance(res, list):
            return res
        return []

    async def last_wallet_tx(self) -> dict:
        res = await self._authed("POST", "Agent/getAgentWallet", {})
        return res if isinstance(res, dict) else {}

    async def wallet_transactions(self, page: int = 1, limit: int = 10) -> list:
        res = await self._authed(
            "POST", "Agent/getAgentTransactionList", {"page": page, "limit": limit}
        )
        if isinstance(res, dict):
            return list(res.get("records") or res.get("data") or [])
        if isinstance(res, list):
            return res
        return []

    async def available_currencies(self) -> dict:
        res = await self._authed("POST", "Agent/getAgentAvailableCurrencies", {})
        return res if isinstance(res, dict) else {}

    async def find_player(self, username: str) -> Optional[dict]:
        q = (username or "").strip().lower()
        if not q:
            return None

        for p in await self.players():
            # [PANEL-V2.1] بعض ردود اللوحة تستخدم login/userName بدل
            # username — البحث بالثلاثة كي لا يُفقد لاعب موجود فعلاً
            un = str(p.get("username") or p.get("login")
                     or p.get("userName") or "").strip().lower()
            if un == q:
                return p
        return None

    async def player_balance(self, player_id) -> float:
        try:
            pid = int(player_id)
        except (ValueError, TypeError):
            pid = player_id

        res = await self._authed("POST", "Player/getPlayerBalanceById", {"playerId": pid})

        if isinstance(res, list) and res:
            for entry in res:
                if isinstance(entry, dict) and entry.get("main"):
                    return float(entry.get("balance") or 0)
            if isinstance(res[0], dict):
                return float(res[0].get("balance") or 0)

        if isinstance(res, dict):
            return float(res.get("balance") or 0)

        try:
            return float(res or 0.0)
        except (ValueError, TypeError):
            return 0.0

    async def register_player(
        self, username: str, password: str, currency: str = None, country_code: str = None
    ) -> dict:
        email = f"p{secrets.token_hex(5)}@gmail.com"
        parent_id = (os.getenv("BETS55_PARENT_ID") or "").strip()

        if not parent_id:
            info = await self.agent_info()
            parent_id = str(info.get("affiliate_id") or "")

        if not parent_id:
            raise PanelError("معرف الوكيل الأب غير معروف — عيّن BETS55_PARENT_ID")

        body = {
            "player": {
                "login": username,
                "password": password,
                "email": email,
                "parentId": parent_id,
            }
        }

        res = await self._authed("POST", "Player/registerPlayer", body)

        # محاولة البحث مع مهلة قصيرة لضمان المزامنة في قاعدة بيانات اللوحة
        # [PANEL-V2.1] 5 محاولات بفواصل متدرجة (~8 ثوانٍ) — كانت 3×0.8ث
        # لا تكفي: ملاحظة حية من المالك — اللاعب يظهر باللوحة فعلاً
        # والبوت يقول «لم يُؤكد ظهوره»
        for i in range(5):
            player = await self.find_player(username)
            if player:
                return player
            await asyncio.sleep(0.5 if i == 0 else 1.5)

        # إذا أعاد الخادم بيانات اللاعب أو معرّفه مباشرة في الرد
        if isinstance(res, dict) and (res.get("playerId") or res.get("id")):
            return {
                "playerId": res.get("playerId") or res.get("id"),
                "username": username,
                "currency": currency or self.cfg["currency"],
            }

        # [PANEL-V2.1] الخادم أكد الاستلام (status:true + result=1) —
        # الإنشاء نجح غالباً وقائمة الوكيل لم تتزامن بعد: نبلّغ النجاح
        # بلا معرف بدل خطأ كاذب (سيناريو مؤكد حياً: اللاعب موجود
        # باللوحة والبوت أظهر «لم يُؤكد ظهوره»)
        if (isinstance(res, int) and res > 0) or (
            isinstance(res, str) and res.strip().isdigit()
        ):
            return {
                "playerId": None,
                "username": username,
                "currency": currency or self.cfg["currency"],
                "unconfirmed": True,
            }

        raise PanelError(
            "أُرسل طلب إنشاء اللاعب ولم يُرفض، لكن لم يظهر في قائمة"
            " الوكيل بعد — تأكد منه خلال لحظات من «📋 اللاعبون»"
        )

    async def deposit_to_player(
        self, player_id, amount: float, comment: str = "", currency: str = None
    ) -> dict:
        if amount <= 0:
            raise PanelError("المبلغ يجب أن يكون أكبر من صفر")

        try:
            pid = int(player_id)
        except (ValueError, TypeError):
            pid = player_id

        body = {
            "amount": amount,
            "comment": comment or "bot",
            "playerId": pid,
            "currencyCode": currency or self.cfg["currency"],
        }

        res = await self._authed("POST", "Player/depositToPlayer", body)
        return {"ok": True, "result": res}

    async def withdraw_from_player(
        self, player_id, amount: float, comment: str = "", currency: str = None
    ) -> dict:
        if amount <= 0:
            raise PanelError("المبلغ يجب أن يكون أكبر من صفر")

        try:
            pid = int(player_id)
        except (ValueError, TypeError):
            pid = player_id

        body = {
            "amount": amount,
            "comment": comment or "bot",
            "playerId": pid,
            "currencyCode": currency or self.cfg["currency"],
        }

        res = await self._authed("POST", "Player/withdrawFromPlayer", body)
        return {"ok": True, "result": res}


# عميل مشترك للبوت
_panel_client: Optional[PanelClient] = None


def get_panel() -> PanelClient:
    global _panel_client
    if _panel_client is None:
        _panel_client = PanelClient()
    return _panel_client
